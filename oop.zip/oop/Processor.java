package oop;

import java.util.ArrayList;
import java.util.Scanner;

public class Processor {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Car> cars = new ArrayList<>();
        
        for (int i = 1; i <= 2; i++) {
            System.out.println("Information my car " + i + ": ");
            System.out.print("Model: "); // corrected the typo here
            String model = scanner.nextLine();
            System.out.print("Year: ");
            int year = scanner.nextInt();
            scanner.nextLine();
            cars.add(new Car(model, year));
        }

        for (Car car : cars) {
            car.displayDetails();
        }
    }
}
